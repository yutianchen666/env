---
name: Bug report
about: Report a bug with the Neural MMO environment or Unity3D Embyr client
title: "[Bug Report]"
labels: ''
assignees: ''

---

Fill out as much of the below as you can. A partial bug report is better than no bug report. After submitting, link your issue on our [Discord](https://discord.gg/BkMmFUC) #support channel 

**OS:** Your operating system

**Description:** What's wrong

**Repro:** How do we reproduce the issue? Minimal scripts are best. Instructions are acceptable. "I don't know" is valid.
