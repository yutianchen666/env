from nmmo.entity.entity import Entity
from nmmo.entity.player import Player
