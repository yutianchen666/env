from nmmo.lib.priorityqueue import PriorityQueue
